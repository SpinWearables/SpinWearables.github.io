<div class="flex-container"><div class="wide-text">
# Step Counter: Step 1, read the motion sensor
</div>
<div class="side-text">
</div>
<div class="code">
```cpp

#include "SpinWearables.h"
using namespace SpinWearables;

void setup() {
  Serial.begin(115200);
  SpinWheel.begin();
}

void loop() {
  SpinWheel.readIMU();
  // The "sum of the squares" is a common way to measure total ammount of motion independent of direction.
  // Mathematicians call it "the norm of the vector describing the motion".
  float total_acceleration = sqrt(SpinWheel.ax*SpinWheel.ax+SpinWheel.ay*SpinWheel.ay+SpinWheel.az*SpinWheel.az);
  Serial.print(total_acceleration);
  Serial.println();
}
```
</div>
</div>