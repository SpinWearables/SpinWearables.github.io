<div class="flex-container"><div class="wide-text">
# Dancing with Color: Step x, have the color wheel change only 
</div>
<div class="side-text">
if there is rotation
</div>
<div class="code">
```cpp

#include "SpinWearables.h"
using namespace SpinWearables;

void setup() {
  SpinWheel.begin();
}

int offset = 0;
int colorChange;

uint8_t angle;

void loop() {
  SpinWheel.readIMU();
  // if rotation is fast, add a step to the offset
  if (abs(SpinWheel.gx) > 1) {
    offset = SpinWheel.gx*100; 
    Serial.println(offset);
  }

  // make the rainbow in the large LEDs
  for (int i=0; i<4; i++) {
    colorChange = offset+i*255/4;
    Serial.println(colorChange);
    SpinWheel.setLargeLED(i, colorWheel(colorChange));
    SpinWheel.setLargeLED(7-i, colorWheel(colorChange));
  }

  float total_acceleration = SpinWheel.ax + SpinWheel.ay + SpinWheel.az
  
  // make a snake in the small LEDs
  // if there is sufficient motion, have the snake move
  if (abs(total_acceleration) > 1) { 
    angle = (millis()>>4)&0xff;    
  }

  // this is a function that we created to display a "snake"
  SpinWheel.setSmallLEDsPointer(angle, 500, 0, 255, 255);

  SpinWheel.drawFrame();
}
```
</div>
</div>